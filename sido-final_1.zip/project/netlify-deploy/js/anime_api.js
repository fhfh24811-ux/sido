// ✅ يعيد تصدير كل شيء من backend مباشرة
export { getAllAnime, getAnimeById, getAnimeByType, getEpisodes, getEpisode, searchAnime } from "../backend/anime_api.js";
